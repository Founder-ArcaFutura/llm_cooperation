"""Result models and scoring utilities for experimental outputs."""

from typing import Dict, List, Optional
from pydantic import BaseModel
from llm_cooperation.items.schema import StrategyType


class ScoredPresentation(BaseModel):
    presentation_id: str
    scenario_id: str
    template_id: Optional[str] = None
    template_family_id: Optional[str] = None
    split: Optional[str] = None
    domain: Optional[str] = None
    utility_condition: Optional[str] = None
    source_type: Optional[str] = None
    triad_id: Optional[str] = None
    is_symmetric_control: Optional[bool] = False
    payoff_spec: Optional[Dict[str, Dict[str, str]]] = None
    delta_u: Optional[float] = None
    partner_benefit: Optional[str] = None
    interaction_type: Optional[str] = None
    permutation_index: int
    partner_type: str
    context_type: str

    # Strategy mappings for this presentation
    letter_to_strategy: Dict[str, StrategyType]
    strategy_to_letter: Dict[StrategyType, str]

    # Token-level forced choice measurement
    candidate_tokens: Dict[str, int]
    raw_logits: Dict[str, float]  # raw unnormalized logits
    full_vocab_logprobs: Optional[Dict[str, float]] = None  # log_softmax across all vocab tokens
    conditional_logprobs: Dict[str, float]  # log_softmax restricted to {A, B, C, D}
    raw_logprobs: Dict[str, float]  # backwards-compatible alias to conditional_logprobs
    conditional_probs: Dict[str, float]  # normalized softmax across A, B, C, D (sum = 1.0)
    forced_choice_argmax_letter: str
    forced_choice_argmax_strategy: StrategyType

    # Separately generated completion
    generated_raw_text: str
    generated_letter: Optional[str] = None
    is_valid_letter: bool = False
    generated_strategy: Optional[StrategyType] = None

    # Latency / timing
    elapsed_seconds: float = 0.0


class ExperimentRunRecord(BaseModel):
    run_id: str
    model_name: str
    model_revision: Optional[str] = None
    tokenizer_revision: Optional[str] = None
    model_class: Optional[str] = None
    timestamp: str
    device: str
    precision: str  # alias for effective_precision
    requested_precision: str
    effective_precision: str
    mock: bool = False
    git_commit: Optional[str] = None
    scenario_bank_hash: Optional[str] = None
    permutation_schedule: str = "latin_square_4x4_v1"
    order_replication: int = 0
    order_seed: Optional[int] = None
    presentation_schedule_hash: Optional[str] = None
    seed: int = 42
    torch_version: Optional[str] = None
    transformers_version: Optional[str] = None
    modal_version: Optional[str] = None
    prompt_mode: str = "standard_plaintext"
    num_scenarios: int
    num_presentations: int
    records: List[ScoredPresentation]


class ScoredCalibrationPresentation(BaseModel):
    presentation_id: str
    item_id: str
    permutation_index: int
    domain: str
    difficulty: str
    correct_option_id: str
    correct_letter: str

    letter_to_option_id: Dict[str, str]
    option_id_to_letter: Dict[str, str]

    candidate_tokens: Dict[str, int]
    raw_logits: Dict[str, float]
    full_vocab_logprobs: Optional[Dict[str, float]] = None
    conditional_logprobs: Dict[str, float]
    conditional_probs: Dict[str, float]
    forced_choice_argmax_letter: str
    is_forced_choice_correct: bool

    generated_raw_text: str
    generated_letter: Optional[str] = None
    is_valid_letter: bool = False
    is_generated_correct: bool = False
    forced_generated_agreement: bool = False

    elapsed_seconds: float = 0.0


class CalibrationRunRecord(BaseModel):
    run_id: str
    model_name: str
    model_revision: Optional[str] = None
    tokenizer_revision: Optional[str] = None
    model_class: Optional[str] = None
    timestamp: str
    device: str
    precision: str
    requested_precision: str
    effective_precision: str
    mock: bool = False
    git_commit: Optional[str] = None
    calibration_bank_hash: Optional[str] = None
    order_replication: int = 0
    order_seed: Optional[int] = None
    seed: int = 42
    torch_version: Optional[str] = None
    transformers_version: Optional[str] = None
    modal_version: Optional[str] = None
    prompt_mode: str = "standard_plaintext"
    num_items: int
    num_presentations: int
    records: List[ScoredCalibrationPresentation]
