# Dose-response / pretraining emergence: integration review notes

This is an exploratory **implementation scaffold**, not a completed real-model experiment.
No pretrained-model dose-response curve or pretraining emergence measurements are included in this PR.
The saved source ZIP contained 94 scenarios, analysis code, a Pythia checkpoint sketch, and synthetic tests.

## Must fix before authorizing real inference

1. **Runner metadata round-trip.** `run_experiment` / `aggregate_by_scenario` must preserve or reattach
   `payoff_spec`, `source_type`, `is_symmetric_control`, and the scenario's real `delta_u`.
   Current shared runner metadata omits payoff specifications. Add a tested bank-to-aggregate join
   (by scenario ID) or explicitly extend the runner output.
2. **Choice crossover.** A four-action choice rate of 0.50 is *not* the point at which
   `P(COOPERATE) == P(INDEPENDENT)`. Fit the choice difference directly and locate its zero.
   For log-probability contrasts, locate zero as well; do not constrain those potentially negative
   log differences to the [0,1] range of a four-parameter probability sigmoid.
3. **True clustering.** Main bank `template_id` includes payoff-tier suffixes. Bootstrap must
   cluster by the underlying scenario family (e.g. `sweep_dose_tpl_001`), retaining all
   payoff levels, partner variants, and permutations in each cluster, not treat each tier as
   an independent experimental unit.
4. **Factorial contrasts.** Current low-benefit and repeated-horizon variants cover only a
   two-template subset, not a fully crossed factorial design; main condition mix differs.
   Restrict estimates to exactly paired template/payoff/partner cells or expand the design.
5. **Checkpoint calibration.** The remote implementation comments promise calibration but
   do not call the existing `run_calibration` function. Incorporate and preserve its actual
   results; ensure each checkpoint's format/number competence is assessed separately.
6. **Protocol arithmetic and command.** Bank = 94 scenarios / 376 counterbalanced presentations,
   not 20 templates / 960 presentations. Generator has six main templates x six payoff tiers x
   two partner identities (72) plus 22 exploratory/control scenarios.
   Documented Modal option `--checkpoint-order` does not match entrypoint `--checkpoint-step`.
   The GPU cost/throughput estimate is not validated and should not be cited as an estimate.
7. **Lexical/payoff equivalence.** Varying text such as 'private efficiency gain' versus
   'substantial sacrifice' can cue the answer independently of numerical payoff. Control for
   textual framing and expose the same numerical payoff table under each condition.
8. **Base branch matters.** `jules_integration` and `main` lack `UtilityCondition` and the
   extended `Scenario.payoff_spec`; this implementation cannot be transplanted unchanged.
   This draft should target `codex/lexical-strategy-bridge` or another branch with the advanced
   Phase 0B schema, and undergo integration tests on that exact base.

## Validation performed while recovering the ZIP

- Python syntax compilation passed on the supplied files.
- Five isolated synthetic analysis/checkpoint tests passed with the ZIP on `PYTHONPATH`.
- Full repository integration, scenario schema, real-model output round-trip, and Modal execution
  have **not** been validated in the recovery environment. No GPU inference was run.

## Next acceptance gate

Keep the PR in draft until all issues above are resolved; add a mock end-to-end test from
frozen scenario bank -> runner JSONL -> scenario aggregation -> dose-response analysis and
show the correct measured `delta_u`, control classifications, log-probability contrasts,
proper group clusters, and crossover extraction.
