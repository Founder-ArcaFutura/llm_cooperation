# One-time recovery: stage Jules's archived experiment into a new feature branch
# and open a DRAFT PR. Does not run real model inference or paid GPU jobs.
param(
    [string]$Repo = "G:\llm_cooperation",
    [string]$Base = "codex/lexical-strategy-bridge",
    [string]$Branch = "feat/dose-response-pretraining-emergence"
)
$ErrorActionPreference = "Stop"
function Check-Exit([string]$Step) { if ($LASTEXITCODE -ne 0) { throw "$Step failed with exit code $LASTEXITCODE. No PR was created." } }
if (-not (Test-Path (Join-Path $Repo ".git"))) { throw "Not a Git repo: $Repo" }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw "Git not found" }
$files = @(
    "data/scenarios_dose_response_exploratory.json",
    "docs/payoff_dose_response_and_emergence_protocol.md",
    "llm_cooperation/analysis/dose_response.py",
    "llm_cooperation/harness/emergence.py",
    "llm_cooperation/items/dose_response_bank.py",
    "modal_pythia_emergence.py",
    "tests/test_dose_response_analysis.py",
    "tests/test_dose_response_bank.py",
    "tests/test_pretraining_emergence.py"
)
Push-Location $Repo
try {
    $changes = git status --porcelain
    Check-Exit "Git status"
    if ($changes) { throw "Working tree has existing changes. Commit or stash them first; nothing was overwritten." }
    $origin = git remote get-url origin
    Check-Exit "Git remote"
    if ($origin -notmatch 'Founder-ArcaFutura/llm_cooperation') { throw "Unexpected remote: $origin" }
    git fetch origin $Base
    Check-Exit "Git fetch"
    git switch -c $Branch "origin/$Base"
    Check-Exit "New branch"
    foreach ($rel in $files) {
        $src = Join-Path $PSScriptRoot $rel
        $dst = Join-Path $Repo $rel
        if (-not (Test-Path $src)) { throw "Missing archived file: $src" }
        if (Test-Path $dst) { throw "File already exists in target branch: $rel" }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item -LiteralPath $src -Destination $dst
    }
    $notes = "docs/DOSE_RESPONSE_PR_REVIEW.md"
    if (Test-Path (Join-Path $Repo $notes)) { throw "Review file already exists" }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot "DOSE_RESPONSE_PR_REVIEW.md") -Destination (Join-Path $Repo $notes)
    git add -- $files $notes
    Check-Exit "Git add"
    git commit -m "Scaffold cooperation payoff dose-response and Pythia emergence (draft)"
    Check-Exit "Git commit"
    git push -u origin $Branch
    Check-Exit "Git push"
    Write-Host "PUSHED: $Branch" -ForegroundColor Green
    if (Get-Command gh -ErrorAction SilentlyContinue) {
        gh pr create --draft --base $Base --head $Branch --title "Draft: cooperation payoff dose-response and pretraining emergence" --body-file (Join-Path $Repo $notes)
        Check-Exit "GitHub PR creation"
        Write-Host "Draft PR created." -ForegroundColor Green
    } else {
        Write-Host "GitHub CLI (gh) isn't installed. Files ARE pushed; ask ChatGPT to open a draft PR for branch $Branch." -ForegroundColor Yellow
    }
} finally { Pop-Location }
