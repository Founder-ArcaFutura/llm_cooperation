# Codex handoff — salvage Jules controlled-repair engine

## Source and target

Source: user-supplied `jules_session_9218804022744716065.zip` (the four enclosed substantive files are included beside this brief). Target repository: `Founder-ArcaFutura/llm_cooperation`; start from the latest `phase_1` branch after merged PR #11. Do not overwrite frozen `data/scenarios_phase0b_utility_matched.json`, `research/controlled_rewrites/production01/`, or PR #11's existing seven repaired records. Create a separate implementation PR.

## What is actually present in the ZIP

- `llm_cooperation/items/controlled_repair_engine.py`: syntax-valid Python, candidate variation functions, token-span measurements with the pinned Qwen 2.5 1.5B tokenizer, single-bank constraint solver, sequential three-bank orchestration, diagnostic semantic flags, guarded model rewrite stub.
- `scripts/repair_controlled_banks_pilot.py`: script assembling existing overlay + frozen scenario records and running 14 cases.
- `tests/test_controlled_repair_engine.py`: six basic tests; not independently executed by this reviewer because `transformers` is absent from the inspection environment.
- `reports/controlled_repair_pilot_report.json`: 14 case results, with 13 reported new token-valid variants and two new complete triads; these counts were independently recomputed from the JSON. Reported duration 0.686 seconds (environment-specific), $0 paid inference.

The ZIP contains **no full-corpus scan report**, no integrated changes to `scripts/repair_controlled_banks_phase1.py`, and no regenerated `production01_repaired` overlay. Jules's claim of 84 new variants and 13 new triads across 124 scenarios is **unverified** from the supplied archive.

## High-priority correctness issues to resolve before using output

1. **Unsafe context-free substitutions.** `TARGETED_SYNONYMS` rewrites `secure` to `claim` anywhere, turning `storage lockers` / `secure lockers` into `claim lockers` in scenario `009_A`'s proposed DISENGAGE action. This is not semantically safe; it was nevertheless recorded with zero semantic risk flags. The pilot also contains lowercased opening words (e.g., `send planned waypoint ...`) and `an early docking access`. Introduce grammatical and context-sensitive rewrite constraints; no unchecked global lexical substitution should be treated as meaning-preserving.
2. **Not truly joint triad optimization.** `optimize_scenario_triad()` fixes existing accepted banks and solves unresolved A then B then C greedily. It does not backtrack or optimize all 12 actions jointly. Candidate ordering can prevent otherwise feasible complete triads. Implement joint selection/backtracking/beam search with explicit objective to maximize complete triads and respect existing accepted source choices.
3. **Weak semantic validator.** `check_semantic_risk()` only checks a small set of partner nouns, binary negation presence and extreme length. It does not verify actors, resources, payoffs, timing, physical feasibility, strategy class, or grammar. Treat all transformed descriptions as `UNADJUDICATED`, and surface before/after diffs for human review; fail closed for modifications to protected scenario facts.
4. **Underpowered test assertions.** The supplied tokenizer test checks only types, not known token counts or an expected pass/fail; the pilot test checks one scenario. Add regression tests for the concrete bad edits above, frozen file hash/provenance, exact tokenizer counts, full-prompt construction, overlay reconstruction, idempotence, metadata (`bank_variant`, `paraphrase_id`, `partial`), cross-bank Jaccard > 0.85, and all existing accepted records remaining intact.
5. **Unreliable pilot diagnostics.** `cross_bank_collisions` is initialized to zero but never updated, making the report's `0` uninformative. `token_span_gap_exceeds_variations` is assigned as a catchall for any unresolved case with nonempty pools, not analytically proven. Compute actual failure reasons and collision statistics from the final selected outputs.
6. **Not integrated.** The pilot doesn't write a versioned overlay or update `manifest.json` / `bank_*_candidates.json` / `unresolved.json`; it does not deliver Jules's final requested output. Integrate the solver with PR #11's compact overlay and write a full-source artifact with reproducible checksums. Preserve PR #11's seven valid repairs.
7. **Optimizer objective is incomplete.** `total_flags * 10 + action_span + prompt_span` ignores semantic edit distance, quality/grammaticality and exact preservation of original actions; a zero-penalty result returns early. Define interpretable objectives and vetoes, not just zero diagnostic flags.
8. **Model-assisted hook is a stub.** It fails closed without authorization, which is good; with authorization it returns `None`. Do not claim functional LLM fallback or call remote inference by default.

## Recommended next task

Port the four files into a **new branch from latest `phase_1`** (or selectively transplant only their useful portions), first adding regression tests exposing the issues above. Replace unsafe substitutions with constrained, auditable candidate generation. Refactor sequential bank solving into joint/backtracking optimization, while preserving immutable accepted records unless an explicitly justified revision is needed. Implement a deterministic compact repair overlay with full provenance and automatic validation. Re-run the **same 14 pilot scenarios** and a separately persisted **124-scenario full scan**, recording token-valid variants, fully completed triads, semantic-review flags, collision counts, time, and edits from originals. Do not report automatic passes as scientifically validated; do not spend money or launch hosted models.

## Acceptance gates

- Exact pinned tokenizer; action and prompt spans <= 1 for every newly accepted quartet.
- No exact or excessive (>0.85 word Jaccard) cross-bank action collisions for corresponding strategy/scenario.
- Zero unexplained new changes to frozen source, production01, or existing accepted repairs.
- Explicitly run and report test results; do not infer pass from prior Jules commentary.
- All transformed actions documented as pending independent semantic adjudication.
- Pilot and full-scan counts independently derivable from serialized outputs, not hard-coded.
- Stop if there is no measurable benefit once semantic/grammar filters are enforced.
