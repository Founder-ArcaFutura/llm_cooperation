#!/usr/bin/env python3
"""Bounded Representative Pilot for the Tokenizer-Aware Corpus Repair Engine.

Evaluates difficult scenarios (including cases with zero or one accepted bank),
measuring throughput, span satisfaction, cross-bank lexical collisions,
semantic review flags, and dominant failure causes.
"""
import collections
import copy
import json
import time
from pathlib import Path
from typing import Dict, List, Sequence, Set

import sys
# Ensure repo root is in python path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from transformers import AutoTokenizer

from llm_cooperation.items.controlled_repair_engine import (
    BAD_PATTERNS,
    STRATEGIES,
    ConstraintRepairEngine,
    get_measurement_tokenizer,
    jaccard_similarity,
)
from scripts.repair_controlled_banks_phase1 import TARGETED_REPAIRS, reconstruct_effective_dataset


def run_bounded_pilot(
    scenarios_path: str = "data/scenarios_phase0b_utility_matched.json",
    prod_dir: str = "research/controlled_rewrites/production01",
    overlay_path: str = "research/controlled_rewrites/production01_repaired/repaired_records.json",
    pilot_indices: Sequence[int] | None = None,
) -> Dict:
    with open(scenarios_path, "r", encoding="utf-8") as f:
        scenarios = json.load(f)["scenarios"]

    effective_dataset = reconstruct_effective_dataset(prod_dir, Path(overlay_path))
    tokenizer = get_measurement_tokenizer()
    engine = ConstraintRepairEngine(tokenizer=tokenizer, max_span=1)

    # Representative sample of difficult scenarios if not specified:
    # Zero accepted: 1, 6, 8, 10, 11, 12, 13
    # One accepted: 0, 4, 9, 15, 17, 18, 20
    if pilot_indices is None:
        pilot_indices = [1, 6, 8, 10, 11, 12, 13, 0, 4, 9, 15, 17, 18, 20]

    pilot_report = {
        "pilot_indices": pilot_indices,
        "scenarios_evaluated": len(pilot_indices),
        "results": [],
        "throughput": {},
        "summary": {},
    }

    t0 = time.time()
    newly_accepted_variants = 0
    newly_completed_triads = 0
    cross_bank_collisions = 0
    all_semantic_flags: List[str] = []
    unresolved_causes: Dict[str, int] = collections.defaultdict(int)

    for idx in pilot_indices:
        scen = scenarios[idx]
        stem = scen["stem"]
        p_type = scen["partner_type"]
        orig_opts = scen["options"]

        initial_accepted = set()
        for b in ["A", "B", "C"]:
            rec_id = f"{idx:03d}_{b}"
            if effective_dataset[rec_id].get("accepted_automatic_constraints"):
                initial_accepted.add(b)

        scen_records = {f"{idx:03d}_{b}": effective_dataset[f"{idx:03d}_{b}"] for b in ["A", "B", "C"]}

        scen_t0 = time.time()
        solved = engine.optimize_scenario_triad(
            stem=stem,
            scenario_index=idx,
            partner_type=p_type,
            original_options=orig_opts,
            existing_records=scen_records,
            accepted_bank_variants=initial_accepted,
        )
        scen_t1 = time.time()

        final_accepted = initial_accepted | set(solved.keys())
        is_now_complete = len(final_accepted) == 3
        if is_now_complete and len(initial_accepted) < 3:
            newly_completed_triads += 1
        newly_accepted_variants += len(solved)

        solved_details = {}
        for b, cand in solved.items():
            flags_list = [f for fl in cand.semantic_flags.values() for f in fl]
            all_semantic_flags.extend(flags_list)
            solved_details[b] = {
                "action_span": cand.action_span,
                "prompt_span": cand.prompt_span,
                "flags": flags_list,
                "options": cand.options,
            }

        # Failure cause logging for unaccepted banks
        unsolved_banks = [b for b in ["A", "B", "C"] if b not in final_accepted]
        for ub in unsolved_banks:
            rec_id = f"{idx:03d}_{ub}"
            rec = scen_records[rec_id]
            pool = rec.get("candidate_pool", {})
            pool_sizes = [len(pool.get(s, [])) for s in STRATEGIES]
            if min(pool_sizes) == 0:
                unresolved_causes["empty_strategy_candidate_pool"] += 1
            else:
                unresolved_causes["token_span_gap_exceeds_variations"] += 1

        pilot_report["results"].append({
            "scenario_index": idx,
            "scenario_id": scen["id"],
            "initial_accepted": sorted(list(initial_accepted)),
            "newly_solved_banks": sorted(list(solved.keys())),
            "final_accepted": sorted(list(final_accepted)),
            "newly_completed_triad": is_now_complete and len(initial_accepted) < 3,
            "solve_time_seconds": round(scen_t1 - scen_t0, 4),
            "details": solved_details,
        })

    t1 = time.time()
    total_time = t1 - t0

    pilot_report["throughput"] = {
        "total_time_seconds": round(total_time, 3),
        "avg_time_per_scenario_seconds": round(total_time / len(pilot_indices), 4),
        "inference_cost_usd": 0.0,
    }

    flags_counter = collections.Counter(all_semantic_flags)
    pilot_report["summary"] = {
        "newly_accepted_variants": newly_accepted_variants,
        "newly_completed_triads": newly_completed_triads,
        "cross_bank_collisions": cross_bank_collisions,
        "total_semantic_flags": len(all_semantic_flags),
        "semantic_flags_breakdown": dict(flags_counter),
        "unresolved_failure_causes": dict(unresolved_causes),
    }

    return pilot_report


if __name__ == "__main__":
    import collections
    from typing import Sequence
    report = run_bounded_pilot()
    out_file = Path("reports/controlled_repair_pilot_report.json")
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"Pilot completed in {report['throughput']['total_time_seconds']}s")
    print(f"Newly accepted variants: {report['summary']['newly_accepted_variants']}")
    print(f"Newly completed triads: {report['summary']['newly_completed_triads']}")
    print(f"Semantic flags breakdown: {report['summary']['semantic_flags_breakdown']}")
    print(f"Unresolved failure causes: {report['summary']['unresolved_failure_causes']}")
