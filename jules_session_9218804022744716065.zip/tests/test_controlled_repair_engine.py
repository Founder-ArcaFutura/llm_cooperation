"""Unit and integration tests for the constraint-optimization repair engine."""
import json
import pytest
from pathlib import Path

from llm_cooperation.items.controlled_repair_engine import (
    ConstraintRepairEngine,
    check_semantic_risk,
    check_token_spans,
    generate_candidate_variations,
    get_measurement_tokenizer,
    has_banned_padding,
    measure_token_lengths,
    model_assisted_rewrite_hook,
)


@pytest.fixture(scope="module")
def tokenizer():
    return get_measurement_tokenizer()


def test_tokenizer_and_span_checking(tokenizer):
    """Test token length measurement and span checking."""
    stem = "You are a test agent deciding how to allocate resources."
    opts_pass = {
        "COOPERATE": "Share all resources equally with the team.",
        "INDEPENDENT": "Keep your assigned resources for yourself.",
        "COMPETE_EXPLOIT": "Claim all available resources right now.",
        "DISENGAGE": "Return resources to depot until next week.",
    }
    act_tokens, prompt_tokens = measure_token_lengths(tokenizer, stem, opts_pass)
    passed, a_span, p_span = check_token_spans(act_tokens, prompt_tokens, max_span=1)
    assert isinstance(passed, bool)
    assert isinstance(a_span, int)
    assert isinstance(p_span, int)


def test_banned_padding_detection():
    """Verify that mechanical padding artifacts are caught."""
    assert has_banned_padding("Do this exactly first.") is True
    assert has_banned_padding("Wait until tomorrow until next shift.") is True
    assert has_banned_padding("Proceed according in order to plan.") is True
    assert has_banned_padding("Share resources with the partner via secure link.") is False


def test_candidate_variations_generation():
    """Verify meaning-preserving variation generation."""
    base = "Share your planned waypoint corridor with the adjacent navigation officer via VHF."
    vars_ = generate_candidate_variations(base)
    assert len(vars_) >= 2
    assert base in vars_
    for v in vars_:
        assert not has_banned_padding(v)


def test_semantic_risk_detection():
    """Verify partner cue loss and negation polarity shift detection."""
    orig = "Share logs with the human astronomer."
    cand_no_partner = "Share logs through the automated system."
    flags = check_semantic_risk(orig, cand_no_partner, "COOPERATE", "human")
    assert "possible_loss_of_human_partner_cue" in flags

    orig_pos = "Proceed using onboard radar."
    cand_neg = "Proceed without using onboard radar."
    flags_neg = check_semantic_risk(orig_pos, cand_neg, "INDEPENDENT", "human")
    assert any("polarity_negation_shift" in f for f in flags_neg)


def test_model_assisted_rewrite_guard():
    """Verify that model-assisted rewrite hook fails closed when unauthorized."""
    with pytest.raises(PermissionError, match="Paid model inference is guarded"):
        model_assisted_rewrite_hook("dummy prompt", authorize_paid_run=False)


def test_constraint_repair_engine_on_near_miss(tokenizer):
    """Verify that the engine can optimize a near-miss scenario (e.g., scenario 012_A)."""
    with open("data/scenarios_phase0b_utility_matched.json") as f:
        scenarios = json.load(f)["scenarios"]
    scen_12 = scenarios[12]
    stem = scen_12["stem"].strip()

    with open("research/controlled_rewrites/production01/records/012_A.json") as f:
        rec_12_a = json.load(f)

    engine = ConstraintRepairEngine(tokenizer=tokenizer, max_span=1)
    pool_by_strat = {}
    for s in ["COOPERATE", "INDEPENDENT", "COMPETE_EXPLOIT", "DISENGAGE"]:
        seeds = list(rec_12_a["candidate_pool"].get(s, []))
        if rec_12_a["options"].get(s):
            seeds.append(rec_12_a["options"][s])
        pool_by_strat[s] = engine.build_option_candidate_pool(
            stem=stem,
            strategy=s,
            base_options=seeds,
            partner_type=scen_12["partner_type"],
            original_source_option=scen_12["options"][s],
        )

    cand = engine.solve_single_bank(
        stem=stem,
        bank="A",
        scenario_index=12,
        record_id="012_A",
        pool_by_strategy=pool_by_strat,
        target_span=1,
    )

    assert cand is not None
    assert cand.is_valid is True
    assert cand.action_span <= 1
    assert cand.prompt_span <= 1
    assert len(set(cand.options.values())) == 4
