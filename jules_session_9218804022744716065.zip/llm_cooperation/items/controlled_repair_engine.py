"""Tokenizer-Aware Constraint-Optimization Repair Engine for Controlled Strategy Banks.

This module provides a reproducible, scalable constraint-optimization engine for repairing
controlled strategy scenarios across Banks A, B, and C under the pinned Qwen tokenizer.

Key features:
1. Pinned measurement tokenizer integration (Qwen/Qwen2.5-1.5B @ 8faed761d45a263340a0528343f099c05c9a4323).
2. Strict verification of both action-only token span <= 1 and full-prompt token span <= 1.
3. Candidate expansion using existing candidate pools and targeted meaning-preserving transformations
   (synonym substitution, determiner adjustments, modal adjustments, particle shifts).
4. Joint 4-strategy selection and cross-bank optimization enforcing:
   - Zero exact duplicate actions across banks for the same scenario.
   - Word Jaccard similarity <= 0.85 across banks.
   - Exclusion of banned mechanical padding patterns (BAD_PATTERNS).
   - Preservation of strategic meaning, partner cues, polarity, and payoff semantics.
5. Fail-closed model-assisted rewrite hook that strictly blocks paid GPU compute without explicit authorization.
6. Diagnostic semantic triage and review flagging for independent adjudication.
"""
from __future__ import annotations

import collections
import copy
import hashlib
import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from transformers import AutoTokenizer

MEASUREMENT_TOKENIZER_NAME = "Qwen/Qwen2.5-1.5B"
PINNED_MEASUREMENT_TOKENIZER_REVISION = "8faed761d45a263340a0528343f099c05c9a4323"
MAX_CROSS_BANK_JACCARD = 0.85

STRATEGIES = ("COOPERATE", "INDEPENDENT", "COMPETE_EXPLOIT", "DISENGAGE")
WORD_RE = re.compile(r"[a-z0-9]+", re.I)

BAD_PATTERNS = [
    re.compile(r"\baccording in order to\b", re.I),
    re.compile(r"\bexactly (?:first|until)\b", re.I),
    re.compile(r"\buntil\b.{0,110}\buntil\b", re.I),
    re.compile(r"\bin order to to\b", re.I),
    re.compile(r"\bthe the\b", re.I),
]


def tokenize_words(text: str) -> List[str]:
    return [w.lower() for w in WORD_RE.findall(text)]


def jaccard_similarity(text1: str, text2: str) -> float:
    s1 = set(tokenize_words(text1))
    s2 = set(tokenize_words(text2))
    if not s1 or not s2:
        return 0.0
    return len(s1 & s2) / len(s1 | s2)
PINNED_MEASUREMENT_TOKENIZER_REVISION = "8faed761d45a263340a0528343f099c05c9a4323"
MAX_CROSS_BANK_JACCARD = 0.85

# Meaning-preserving synonym & phrasing replacement map
# Directed transformations that preserve exact technical and strategic semantics
TARGETED_SYNONYMS = [
    # Verbs / Modals / Prepositions / Connectives
    (r"\bvia\b", ["through", "using", "by"]),
    (r"\bthrough\b", ["via", "using"]),
    (r"\butilizing\b", ["using", "applying"]),
    (r"\busing\b", ["via", "through"]),
    (r"\btransmit\b", ["send", "forward", "submit"]),
    (r"\bsend\b", ["forward", "submit", "transmit"]),
    (r"\bforward\b", ["send", "submit", "transmit"]),
    (r"\bsubmit\b", ["send", "forward", "transmit"]),
    (r"\bdelay\b", ["postpone", "defer", "hold"]),
    (r"\bpostpone\b", ["delay", "defer", "hold"]),
    (r"\bdefer\b", ["delay", "postpone", "hold"]),
    (r"\bpromptly\b", ["immediately", "rapidly", "quickly"]),
    (r"\bsolely\b", ["only", "exclusively", "alone"]),
    (r"\balone\b", ["solely", "independently", "without coordination"]),
    (r"\bwithout external coordination\b", ["independently", "alone", "without coordination"]),
    (r"\bwithout coordination\b", ["independently", "alone", "without external coordination"]),
    (r"\bindependently\b", ["alone", "solely", "without coordination"]),
    (r"\bcease\b", ["halt", "stop", "suspend"]),
    (r"\bhalt\b", ["cease", "stop", "suspend"]),
    (r"\bsuspend\b", ["halt", "pause", "cease"]),
    (r"\bsecure\b", ["claim", "obtain", "acquire"]),
    (r"\bclaim\b", ["secure", "seize", "obtain"]),
    (r"\bpreempt\b", ["claim", "override", "prioritize"]),
    (r"\bprioritize\b", ["favor", "fast-track", "claim"]),
    (r"\bcoordinate\b", ["align", "synchronize", "share"]),
    (r"\bsynchronize\b", ["coordinate", "align", "match"]),
    (r"\balign\b", ["coordinate", "synchronize", "match"]),
    (r"\bcollaborate with\b", ["coordinate with", "partner with", "work with"]),
    (r"\bawait\b", ["wait for", "hold for"]),
    (r"\bwait for\b", ["await", "hold for"]),
    (r"\bcommence\b", ["begin", "start"]),
    (r"\bbegin\b", ["start", "commence"]),
    (r"\bstart\b", ["begin", "commence"]),
]


def get_measurement_tokenizer(
    tokenizer_name: str = MEASUREMENT_TOKENIZER_NAME,
    revision: str = PINNED_MEASUREMENT_TOKENIZER_REVISION,
    local_files_only: bool = True,
) -> AutoTokenizer:
    """Load the pinned measurement tokenizer offline."""
    return AutoTokenizer.from_pretrained(
        tokenizer_name,
        revision=revision,
        local_files_only=local_files_only,
    )


def measure_token_lengths(
    tokenizer: AutoTokenizer,
    stem: str,
    options: Dict[str, str],
) -> Tuple[Dict[str, int], Dict[str, int]]:
    """Measure action-only and full-prompt token counts for 4 options."""
    action_tokens: Dict[str, int] = {}
    full_prompt_tokens: Dict[str, int] = {}
    clean_stem = stem.strip()
    for s in STRATEGIES:
        act = options[s].strip()
        action_tokens[s] = len(tokenizer.encode(act, add_special_tokens=False))
        prompt_text = f"{clean_stem}\n\nAction: {act}\nDecision:"
        full_prompt_tokens[s] = len(tokenizer.encode(prompt_text, add_special_tokens=False))
    return action_tokens, full_prompt_tokens


def check_token_spans(
    action_tokens: Dict[str, int],
    full_prompt_tokens: Dict[str, int],
    max_span: int = 1,
) -> Tuple[bool, int, int]:
    """Check whether both action and prompt spans satisfy span <= max_span."""
    a_span = max(action_tokens.values()) - min(action_tokens.values())
    p_span = max(full_prompt_tokens.values()) - min(full_prompt_tokens.values())
    passed = (a_span <= max_span) and (p_span <= max_span)
    return passed, a_span, p_span


def has_banned_padding(text: str) -> bool:
    """Check if text contains any banned mechanical padding pattern."""
    for pat in BAD_PATTERNS:
        if pat.search(text):
            return True
    return False


def check_semantic_risk(
    original_text: str,
    candidate_text: str,
    strategy: str,
    partner_type: str,
) -> List[str]:
    """Detect potential semantic risk or distortion in a rewritten option."""
    flags: List[str] = []
    orig_words = set(tokenize_words(original_text))
    cand_words = set(tokenize_words(candidate_text))

    # 1. Partner cue preservation
    if partner_type == "human":
        human_cues = {
            "human", "person", "colleague", "partner", "operator", "crew",
            "specialist", "astronomer", "doctor", "researcher", "investigator", "counterpart"
        }
        if (orig_words & human_cues) and not (cand_words & human_cues):
            flags.append("possible_loss_of_human_partner_cue")
    elif partner_type == "ai":
        ai_cues = {
            "ai", "automated", "algorithm", "system", "synthetic", "bot",
            "autonomous", "software", "agent", "subsystem"
        }
        if (orig_words & ai_cues) and not (cand_words & ai_cues):
            flags.append("possible_loss_of_ai_partner_cue")

    # 2. Polarity shift (negation introduced or removed)
    neg_words = {"not", "never", "no", "neither", "none", "without", "refuse", "halt", "cancel", "decline"}
    orig_neg = bool(orig_words & neg_words)
    cand_neg = bool(cand_words & neg_words)
    if orig_neg != cand_neg and strategy in ("COOPERATE", "INDEPENDENT"):
        if not orig_neg and cand_neg:
            flags.append("polarity_negation_shift(orig=False,cand=True)")
        else:
            flags.append("polarity_negation_shift(orig=True,cand=False)")

    # 3. Excessive length deviation
    orig_len = len(original_text.split())
    cand_len = len(candidate_text.split())
    if cand_len < 0.45 * orig_len:
        flags.append(f"severe_compression({cand_len}w_vs_{orig_len}w)")
    elif cand_len > 2.2 * orig_len and orig_len >= 6:
        flags.append(f"severe_expansion({cand_len}w_vs_{orig_len}w)")

    return flags


def generate_candidate_variations(
    base_text: str,
    max_variations: int = 40,
) -> List[str]:
    """Generate fluent meaning-preserving phrasing variations for an option.
    
    Uses:
    1. Base text intact
    2. Determiner adjustments (e.g., adding or removing 'the', 'your', 'assigned')
    3. Safe synonym substitutions
    4. Minor word-order / connective shifts
    """
    clean = base_text.strip()
    if clean.endswith("."):
        clean_no_period = clean[:-1]
    else:
        clean_no_period = clean

    variations: Set[str] = {clean}

    # 1. Determiner & possessive shifts
    determiner_pairs = [
        (r"\bthe scheduled route\b", "its scheduled route"),
        (r"\byour scheduled route\b", "the scheduled route"),
        (r"\byour assigned\b", "the assigned"),
        (r"\bthe assigned\b", "your assigned"),
        (r"\byour local\b", "the local"),
        (r"\bthe local\b", "your local"),
        (r"\byour planned\b", "the planned"),
        (r"\bthe planned\b", "your planned"),
        (r"\byour observation\b", "the observation"),
        (r"\bthe observation\b", "your observation"),
        (r"\bthe automated\b", "an automated"),
        (r"\ban automated\b", "the automated"),
        (r"\bthe shared\b", "a shared"),
        (r"\ba shared\b", "the shared"),
        (r"\bto claim early\b", "to claim an early"),
        (r"\bto claim an early\b", "to claim early"),
        (r"\bto secure early\b", "to secure an early"),
        (r"\bto secure an early\b", "to secure early"),
        (r"\bin outer harbor\b", "in the outer harbor"),
        (r"\bin the outer harbor\b", "in outer harbor"),
        (r"\binto central fairway\b", "into the central fairway"),
        (r"\binto the central fairway\b", "into central fairway"),
    ]
    for pattern, repl in determiner_pairs:
        if re.search(pattern, clean, re.I):
            var = re.sub(pattern, repl, clean, count=1, flags=re.I)
            if not has_banned_padding(var):
                variations.add(var)

    # 2. Targeted synonym substitutions
    for pat_str, replacements in TARGETED_SYNONYMS:
        if re.search(pat_str, clean, re.I):
            for repl in replacements:
                var = re.sub(pat_str, repl, clean, count=1, flags=re.I)
                if not has_banned_padding(var):
                    variations.add(var)

    # 3. Determiner removal / addition at key positions (e.g., 'via VHF' vs 'via the VHF')
    minor_shifts = [
        (r"\bvia VHF\b", "over VHF"),
        (r"\bover VHF\b", "via VHF"),
        (r"\bvia VHF radio\b", "over VHF radio"),
        (r"\bwithout any external coordination\b", "without external coordination"),
        (r"\bwithout external coordination\b", "without any external coordination"),
        (r"\bsolely through\b", "through"),
        (r"\bsolely based on\b", "based solely on"),
        (r"\bbased solely on\b", "solely based on"),
        (r"\bvia the shared\b", "through the shared"),
        (r"\bthrough the shared\b", "via the shared"),
    ]
    for pattern, repl in minor_shifts:
        if re.search(pattern, clean, re.I):
            var = re.sub(pattern, repl, clean, count=1, flags=re.I)
            if not has_banned_padding(var):
                variations.add(var)

    # Filter out variations that introduce banned patterns
    valid_variations = [v for v in variations if not has_banned_padding(v)]
    return sorted(valid_variations)[:max_variations]


@dataclass
class CandidateOption:
    text: str
    strategy: str
    action_tokens: int
    prompt_tokens: int
    semantic_flags: List[str] = field(default_factory=list)
    source: str = "original"


@dataclass
class ScenarioBankCandidate:
    record_id: str
    bank: str
    scenario_index: int
    options: Dict[str, str]
    action_tokens: Dict[str, int]
    prompt_tokens: Dict[str, int]
    action_span: int
    prompt_span: int
    is_valid: bool
    semantic_flags: Dict[str, List[str]]
    repair_source: str = "deterministic_optimizer"


class ConstraintRepairEngine:
    """Joint 4-strategy and multi-bank constraint optimizer."""

    def __init__(
        self,
        tokenizer: Optional[AutoTokenizer] = None,
        max_span: int = 1,
        max_cross_bank_jaccard: float = MAX_CROSS_BANK_JACCARD,
    ):
        self.tokenizer = tokenizer or get_measurement_tokenizer()
        self.max_span = max_span
        self.max_cross_bank_jaccard = max_cross_bank_jaccard

    def build_option_candidate_pool(
        self,
        stem: str,
        strategy: str,
        base_options: Sequence[str],
        partner_type: str,
        original_source_option: str,
    ) -> List[CandidateOption]:
        """Build and measure token counts for all variations of a strategy option."""
        seen_texts: Set[str] = set()
        pool: List[CandidateOption] = []
        clean_stem = stem.strip()

        for base in base_options:
            if not base or not base.strip():
                continue
            variations = generate_candidate_variations(base)
            for var in variations:
                v_clean = var.strip()
                if not v_clean.endswith("."):
                    v_clean += "."
                if v_clean in seen_texts:
                    continue
                seen_texts.add(v_clean)

                act_len = len(self.tokenizer.encode(v_clean, add_special_tokens=False))
                prm_text = f"{clean_stem}\n\nAction: {v_clean}\nDecision:"
                prm_len = len(self.tokenizer.encode(prm_text, add_special_tokens=False))
                flags = check_semantic_risk(original_source_option, v_clean, strategy, partner_type)

                pool.append(
                    CandidateOption(
                        text=v_clean,
                        strategy=strategy,
                        action_tokens=act_len,
                        prompt_tokens=prm_len,
                        semantic_flags=flags,
                        source="pool_variation" if v_clean != base else "candidate_pool",
                    )
                )

        # Sort pool by length and semantic flags
        pool.sort(key=lambda c: (len(c.semantic_flags), c.action_tokens, len(c.text)))
        return pool

    def solve_single_bank(
        self,
        stem: str,
        bank: str,
        scenario_index: int,
        record_id: str,
        pool_by_strategy: Dict[str, List[CandidateOption]],
        target_span: int = 1,
        existing_banks_options: Optional[Dict[str, Dict[str, str]]] = None,
    ) -> Optional[ScenarioBankCandidate]:
        """Find an optimal 4-strategy assignment satisfying spans and diversity constraints."""
        strategies = list(STRATEGIES)
        candidates_coop = pool_by_strategy.get("COOPERATE", [])
        candidates_indep = pool_by_strategy.get("INDEPENDENT", [])
        candidates_comp = pool_by_strategy.get("COMPETE_EXPLOIT", [])
        candidates_dis = pool_by_strategy.get("DISENGAGE", [])

        if not (candidates_coop and candidates_indep and candidates_comp and candidates_dis):
            return None

        # Group candidates by prompt_tokens for fast indexed pruning
        best_candidate: Optional[ScenarioBankCandidate] = None
        min_penalty = float("inf")

        # Iterate over possible prompt length centers
        all_prompt_lens = set(c.prompt_tokens for s in strategies for c in pool_by_strategy[s])

        for center_prm in sorted(all_prompt_lens):
            # Target range: [center_prm, center_prm + target_span]
            valid_prm = {center_prm, center_prm + target_span}

            c_coop_filt = [c for c in candidates_coop if c.prompt_tokens in valid_prm]
            if not c_coop_filt:
                continue

            for opt_coop in c_coop_filt:
                c_indep_filt = [
                    c for c in candidates_indep
                    if c.prompt_tokens in valid_prm
                    and abs(c.action_tokens - opt_coop.action_tokens) <= target_span
                ]
                if not c_indep_filt:
                    continue

                for opt_indep in c_indep_filt:
                    c_comp_filt = [
                        c for c in candidates_comp
                        if c.prompt_tokens in valid_prm
                        and abs(c.action_tokens - opt_coop.action_tokens) <= target_span
                        and abs(c.action_tokens - opt_indep.action_tokens) <= target_span
                    ]
                    if not c_comp_filt:
                        continue

                    for opt_comp in c_comp_filt:
                        c_dis_filt = [
                            c for c in candidates_dis
                            if c.prompt_tokens in valid_prm
                            and abs(c.action_tokens - opt_coop.action_tokens) <= target_span
                            and abs(c.action_tokens - opt_indep.action_tokens) <= target_span
                            and abs(c.action_tokens - opt_comp.action_tokens) <= target_span
                        ]
                        if not c_dis_filt:
                            continue

                        for opt_dis in c_dis_filt:
                            options_map = {
                                "COOPERATE": opt_coop.text,
                                "INDEPENDENT": opt_indep.text,
                                "COMPETE_EXPLOIT": opt_comp.text,
                                "DISENGAGE": opt_dis.text,
                            }
                            # Check distinctness within 4 strategies
                            if len(set(options_map.values())) < 4:
                                continue

                            # Cross-bank collision and similarity checks against already accepted banks
                            collides = False
                            if existing_banks_options:
                                for ex_bank, ex_opts in existing_banks_options.items():
                                    for s in STRATEGIES:
                                        t1 = options_map[s].strip()
                                        t2 = ex_opts[s].strip()
                                        if t1.casefold() == t2.casefold():
                                            collides = True
                                            break
                                        if jaccard_similarity(t1, t2) > self.max_cross_bank_jaccard:
                                            collides = True
                                            break
                                    if collides:
                                        break
                            if collides:
                                continue

                            # Calculate penalty (prefer fewest semantic flags, minimum span, balanced lengths)
                            total_flags = (
                                len(opt_coop.semantic_flags)
                                + len(opt_indep.semantic_flags)
                                + len(opt_comp.semantic_flags)
                                + len(opt_dis.semantic_flags)
                            )
                            act_lens = {
                                "COOPERATE": opt_coop.action_tokens,
                                "INDEPENDENT": opt_indep.action_tokens,
                                "COMPETE_EXPLOIT": opt_comp.action_tokens,
                                "DISENGAGE": opt_dis.action_tokens,
                            }
                            prm_lens = {
                                "COOPERATE": opt_coop.prompt_tokens,
                                "INDEPENDENT": opt_indep.prompt_tokens,
                                "COMPETE_EXPLOIT": opt_comp.prompt_tokens,
                                "DISENGAGE": opt_dis.prompt_tokens,
                            }
                            a_span = max(act_lens.values()) - min(act_lens.values())
                            p_span = max(prm_lens.values()) - min(prm_lens.values())

                            penalty = total_flags * 10 + a_span + p_span
                            if penalty < min_penalty:
                                min_penalty = penalty
                                best_candidate = ScenarioBankCandidate(
                                    record_id=record_id,
                                    bank=bank,
                                    scenario_index=scenario_index,
                                    options=options_map,
                                    action_tokens=act_lens,
                                    prompt_tokens=prm_lens,
                                    action_span=a_span,
                                    prompt_span=p_span,
                                    is_valid=(a_span <= target_span and p_span <= target_span),
                                    semantic_flags={
                                        "COOPERATE": opt_coop.semantic_flags,
                                        "INDEPENDENT": opt_indep.semantic_flags,
                                        "COMPETE_EXPLOIT": opt_comp.semantic_flags,
                                        "DISENGAGE": opt_dis.semantic_flags,
                                    },
                                    repair_source="constraint_optimizer_pool_search",
                                )
                                # If zero penalty (no flags, 0 span), we can stop search early
                                if penalty == 0:
                                    return best_candidate

        return best_candidate

    def optimize_scenario_triad(
        self,
        stem: str,
        scenario_index: int,
        partner_type: str,
        original_options: Dict[str, str],
        existing_records: Dict[str, Dict[str, Any]],
        accepted_bank_variants: Set[str],
    ) -> Dict[str, ScenarioBankCandidate]:
        """Jointly optimize remaining banks for a scenario to complete the triad."""
        results: Dict[str, ScenarioBankCandidate] = {}
        established_bank_options: Dict[str, Dict[str, str]] = {}

        # 1. Register already accepted banks as fixed constraints
        for bank in ["A", "B", "C"]:
            rec_id = f"{scenario_index:03d}_{bank}"
            if bank in accepted_bank_variants and rec_id in existing_records:
                rec = existing_records[rec_id]
                if rec.get("accepted_automatic_constraints"):
                    established_bank_options[bank] = copy.deepcopy(rec["options"])

        # 2. Process unresolved banks in priority order
        unresolved_banks = [b for b in ["A", "B", "C"] if b not in established_bank_options]

        for bank in unresolved_banks:
            rec_id = f"{scenario_index:03d}_{bank}"
            rec = existing_records.get(rec_id, {})
            candidate_pool = rec.get("candidate_pool", {})

            # Build candidate options per strategy
            pool_by_strat: Dict[str, List[CandidateOption]] = {}
            for s in STRATEGIES:
                raw_cands = candidate_pool.get(s, [])
                # Also include current options and original options as seeds
                current_opt = rec.get("options", {}).get(s, "")
                orig_opt = original_options.get(s, "")
                combined_seeds = list(raw_cands)
                if current_opt and current_opt not in combined_seeds:
                    combined_seeds.append(current_opt)
                if orig_opt and orig_opt not in combined_seeds:
                    combined_seeds.append(orig_opt)

                pool_by_strat[s] = self.build_option_candidate_pool(
                    stem=stem,
                    strategy=s,
                    base_options=combined_seeds,
                    partner_type=partner_type,
                    original_source_option=orig_opt,
                )

            # Attempt to solve with existing established banks as collision constraints
            cand = self.solve_single_bank(
                stem=stem,
                bank=bank,
                scenario_index=scenario_index,
                record_id=rec_id,
                pool_by_strategy=pool_by_strat,
                target_span=self.max_span,
                existing_banks_options=established_bank_options,
            )

            if cand and cand.is_valid:
                results[bank] = cand
                established_bank_options[bank] = copy.deepcopy(cand.options)

        return results


def model_assisted_rewrite_hook(
    prompt: str,
    authorize_paid_run: bool = False,
) -> Optional[Dict[str, str]]:
    """Hook for targeted model-assisted rewriting with fail-closed paid-inference guard.
    
    If paid run is not explicitly authorized via authorize_paid_run or ALLOW_PAID_RUN,
    this function raises ValueError or fails closed to avoid any cloud compute costs.
    """
    allow_env = os.environ.get("ALLOW_PAID_RUN", "").lower() in ("true", "1")
    if not (authorize_paid_run or allow_env):
        raise PermissionError(
            "Paid model inference is guarded. Pass authorize_paid_run=True or set "
            "ALLOW_PAID_RUN=true to authorize remote generation."
        )
    # Offline mock execution / stub for remote Modal invocation when authorized
    return None
